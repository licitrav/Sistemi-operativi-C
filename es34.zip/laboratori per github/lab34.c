#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <fcntl.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>


#define HEAD 12
#define REC 8


typedef enum{
    EMPTY,
    TO_ELABORATE,
    DONE
}stato;

typedef struct{
    u_int8_t blocco[REC];
    char filename[255];
    int esito;
}record;
typedef struct{
    record controllo;
    stato attuale;
    int islast;
}slot;
typedef struct{
    slot broad;
    slot loopback;
    slot mal;
    pthread_cond_t do_broad;
    pthread_cond_t do_loopback;
    pthread_cond_t do_mal;
    pthread_cond_t letto;
    pthread_mutex_t lock;
    int lett_rim; 
}comm_args;

typedef struct{
    comm_args* args;
    int id;
    u_int32_t broad_dic;
    u_int32_t loop_dic;
    u_int32_t mal_dic;
    u_int32_t chek_broad;
    u_int32_t chek_loop;
    u_int32_t chek_mal;
    char filename[255];
}lect_args;
void printBlock(u_int8_t block[REC], int len){
    for(int i=0;i<len;i++)printf("%u ",block[i]);
    printf("\n");
}
void printIP(u_int8_t block[4], int len){
    for(int i=0;i<len;i++)printf("%u ",block[i]);
    printf("\n");
}

void *lettore(void *arg){
    lect_args* args=(lect_args*)arg;
    int fd;
    u_int8_t *p;
    struct stat sb;
    off_t h;
    fd=open(args->filename,O_RDONLY);
    if(fd==-1){
        perror("Errore apertura del file\n");
        pthread_mutex_lock(&args->args->lock);
        args->args->lett_rim--;
        if(args->args->lett_rim==0){
            args->args->broad.islast=1;
            args->args->loopback.islast=1;
            args->args->mal.islast=1;
            pthread_cond_signal(&args->args->do_broad);
            pthread_cond_signal(&args->args->do_loopback);
            pthread_cond_signal(&args->args->do_mal);
            pthread_mutex_unlock(&args->args->lock);
        }
        else pthread_mutex_unlock(&args->args->lock);
        pthread_exit(NULL);
    }
    if(fstat(fd,&sb)==-1){
        perror("Errore in fstat\n");
        pthread_mutex_lock(&args->args->lock);
        args->args->lett_rim--;
        if(args->args->lett_rim==0){
            args->args->broad.islast=1;
            args->args->loopback.islast=1;
            args->args->mal.islast=1;
            pthread_cond_signal(&args->args->do_broad);
            pthread_cond_signal(&args->args->do_loopback);
            pthread_cond_signal(&args->args->do_mal);
            pthread_mutex_unlock(&args->args->lock);
        }
        else pthread_mutex_unlock(&args->args->lock);
        pthread_exit(NULL);
    }
    p=mmap(NULL,sb.st_size,PROT_READ,MAP_PRIVATE,fd,0);
    if(p==MAP_FAILED){
        perror("Errore nella mmap del file\n");
        pthread_mutex_lock(&args->args->lock);
        args->args->lett_rim--;
        if(args->args->lett_rim==0){
            args->args->broad.islast=1;
            args->args->loopback.islast=1;
            args->args->mal.islast=1;
            pthread_cond_signal(&args->args->do_broad);
            pthread_cond_signal(&args->args->do_loopback);
            pthread_cond_signal(&args->args->do_mal);
            pthread_mutex_unlock(&args->args->lock);
        }
        else pthread_mutex_unlock(&args->args->lock);
        pthread_exit(NULL);
    }
    if(close(fd)==-1){
        perror("Errore nella chiusura del file\n");
        pthread_mutex_lock(&args->args->lock);
        args->args->lett_rim--;
        if(args->args->lett_rim==0){
            args->args->broad.islast=1;
            args->args->loopback.islast=1;
            args->args->mal.islast=1;
            pthread_cond_signal(&args->args->do_broad);
            pthread_cond_signal(&args->args->do_loopback);
            pthread_cond_signal(&args->args->do_mal);
            pthread_mutex_unlock(&args->args->lock);
        }
        else pthread_mutex_unlock(&args->args->lock);
        pthread_exit(NULL);
    }
    u_int8_t header[HEAD];
    for(h=0;h<HEAD;h++){
        header[h]=p[h];
    }
    args->broad_dic=(u_int32_t)header[0]|(u_int32_t)header[1]<<8|(u_int32_t)header[2]<<16|(u_int32_t)header[3]<<24;
    args->loop_dic=(u_int32_t)header[4]|(u_int32_t)header[5]<<8|(u_int32_t)header[6]<<16|(u_int32_t)header[7]<<24;
    args->mal_dic=(u_int32_t)header[8]|(u_int32_t)header[9]<<8|(u_int32_t)header[10]<<16|(u_int32_t)header[11]<<24;
    printf("[READ-%d] leggo il file %s che ha %u broadcast dichiarati, %u loopback dichiarati e %u malformati\n",args->id,args->filename,args->broad_dic,args->loop_dic,args->mal_dic);
    int tot_record=(sb.st_size-HEAD)/REC;
    int counter=1;
    for(int i=0;i<tot_record;i++){
        off_t offeset=HEAD+(off_t)i*REC;
        record t;
        strcpy(t.filename,args->filename);
        for(int j=0;j<REC;j++)t.blocco[j]=p[j+offeset];
        t.esito=0;
        flockfile(stdout);
        printf("[READ-%d] blocco n.%d prelevato : ",args->id,counter);
        printBlock(t.blocco,REC);
        funlockfile(stdout);
        //Inizio verifica broadcast
        pthread_mutex_lock(&args->args->lock);
        while(args->args->broad.attuale!=EMPTY)pthread_cond_wait(&args->args->letto,&args->args->lock);
        args->args->broad.attuale=TO_ELABORATE;
        args->args->broad.islast=0;
        args->args->broad.controllo=t;
        printf("[READ-%d] mando il segnale\n",args->id);
        pthread_cond_signal(&args->args->do_broad);
        pthread_mutex_unlock(&args->args->lock);
        //Controllo l'arrivo
        pthread_mutex_lock(&args->args->lock);
        while(args->args->broad.attuale!=DONE)pthread_cond_wait(&args->args->letto,&args->args->lock);
        args->args->broad.attuale=EMPTY;
        if(args->args->broad.controllo.esito==1){
                args->chek_broad++;
                pthread_cond_broadcast(&args->args->letto);
                pthread_mutex_unlock(&args->args->lock);
                continue;
        }
        pthread_cond_broadcast(&args->args->letto);
        pthread_mutex_unlock(&args->args->lock);
        //Inizio verifica loopback
        pthread_mutex_lock(&args->args->lock);
        while(args->args->loopback.attuale!=EMPTY)pthread_cond_wait(&args->args->letto,&args->args->lock);
        args->args->loopback.attuale=TO_ELABORATE;
        args->args->loopback.islast=0;
        args->args->loopback.controllo=t;
        pthread_cond_signal(&args->args->do_loopback);
        pthread_mutex_unlock(&args->args->lock);
        //Controllo l'arrivo
        pthread_mutex_lock(&args->args->lock);
        while(args->args->loopback.attuale!=DONE)pthread_cond_wait(&args->args->letto,&args->args->lock);
        args->args->loopback.attuale=EMPTY;
        if(args->args->loopback.controllo.esito==1){
                args->chek_loop++;
                pthread_cond_broadcast(&args->args->letto);
                pthread_mutex_unlock(&args->args->lock);
                continue;
        }
        pthread_cond_broadcast(&args->args->letto);
        pthread_mutex_unlock(&args->args->lock);
        //Inizio verifica malformato
        pthread_mutex_lock(&args->args->lock);
        while(args->args->mal.attuale!=EMPTY)pthread_cond_wait(&args->args->letto,&args->args->lock);
        args->args->mal.attuale=TO_ELABORATE;
        args->args->mal.islast=0;
        args->args->mal.controllo=t;
        pthread_cond_signal(&args->args->do_mal);
        pthread_mutex_unlock(&args->args->lock);
        //Controllo l'arrivo
        pthread_mutex_lock(&args->args->lock);
        while(args->args->mal.attuale!=DONE)pthread_cond_wait(&args->args->letto,&args->args->lock);
        args->args->mal.attuale=EMPTY;
        if(args->args->mal.controllo.esito==1){
                args->chek_mal++;
        }
        pthread_cond_broadcast(&args->args->letto);
        pthread_mutex_unlock(&args->args->lock);
        counter++;
    }
    if(munmap(p,sb.st_size)==-1){
        perror("Errore nella munmap\n");
    }
    pthread_mutex_lock(&args->args->lock);
        args->args->lett_rim--;
        if(args->args->lett_rim==0){
            args->args->broad.islast=1;
            args->args->loopback.islast=1;
            args->args->mal.islast=1;
            pthread_cond_signal(&args->args->do_broad);
            pthread_cond_signal(&args->args->do_loopback);
            pthread_cond_signal(&args->args->do_mal);
            pthread_mutex_unlock(&args->args->lock);
        }
        else pthread_mutex_unlock(&args->args->lock);
        printf("[READ-%d] terminazione con %d record letti\n",args->id,counter);
        pthread_exit(NULL);
}

void *broadcast(void *arg){
    comm_args *args=(comm_args*)arg;
    int counter=1;
    while(1){
        pthread_mutex_lock(&args->lock);
        while(args->broad.attuale!=TO_ELABORATE&&args->broad.islast!=1)pthread_cond_wait(&args->do_broad,&args->lock);
        if(args->broad.islast==1){
            pthread_mutex_unlock(&args->lock);
            break;
        }
        u_int8_t ip[4];
        for(int i=0;i<4;i++)ip[i]=args->broad.controllo.blocco[i];
        u_int16_t porta=args->broad.controllo.blocco[4]|args->broad.controllo.blocco[5];
        u_int8_t pad[2]={args->broad.controllo.blocco[6],args->broad.controllo.blocco[7]};
        printf("[BROADCAST] controllo record %d dal file %s-> ",counter,args->broad.controllo.filename);
        pthread_mutex_unlock(&args->lock);
        flockfile(stdout);
        printIP(ip,4);
        printf("[BROADCAST] Numero di porta ->%u e padding %u %u",porta,pad[0],pad[1]);
        funlockfile(stdout);
        int check=0;
        for(int i=0;i<4;i++){
            if(ip[i]==255)check++;
            else break;
        }
        if(check==4){
            printf("[BROADCAST] controllo del record positivo\n");
            pthread_mutex_lock(&args->lock);
            args->broad.controllo.esito=1;
            pthread_mutex_unlock(&args->lock);
        }
        else   printf("[BROADCAST] controllo del record negativo\n");
         pthread_mutex_lock(&args->lock);
        args->broad.attuale=DONE;
        pthread_cond_broadcast(&args->letto);
        pthread_mutex_unlock(&args->lock);
        counter++;
    }
    printf("[BROADCAST] terminazione con %d record verificati\n",counter);
    pthread_exit(NULL);
}

void *loopback(void *arg){
    comm_args *args=(comm_args*)arg;
    int counter=1;
    while(1){
        pthread_mutex_lock(&args->lock);
        while(args->loopback.attuale!=TO_ELABORATE&&args->loopback.islast!=1)pthread_cond_wait(&args->do_loopback,&args->lock);
        if(args->loopback.islast==1){
            pthread_mutex_unlock(&args->lock);
            break;
        }
        u_int8_t ip[4];
        for(int i=0;i<4;i++)ip[i]=args->loopback.controllo.blocco[i];
        u_int16_t porta=args->loopback.controllo.blocco[4]|args->loopback.controllo.blocco[5];
        u_int8_t pad[2]={args->loopback.controllo.blocco[6],args->loopback.controllo.blocco[7]};
        printf("[LOOPBACK] controllo record %d dal file %s-> ",counter,args->loopback.controllo.filename);
        pthread_mutex_unlock(&args->lock);
        flockfile(stdout);
        printIP(ip,4);
        printf("[LOOPBACK] Numero di porta ->%u e padding %u %u",porta,pad[0],pad[1]);
        funlockfile(stdout);
        if(ip[0]==127){
            printf("[LOOPBACK] controllo del record positivo\n");
            pthread_mutex_lock(&args->lock);
            args->loopback.controllo.esito=1;
            pthread_mutex_unlock(&args->lock);
        }
        else   printf("[LOOPBACK] controllo del record negativo\n");
        pthread_mutex_lock(&args->lock);
        args->loopback.attuale=DONE;
        pthread_cond_broadcast(&args->letto);
        pthread_mutex_unlock(&args->lock);
        counter++;
    }
    printf("[LOOPBACK] terminazione con %d record verificati\n",counter);
    pthread_exit(NULL);
}

void *malformato(void *arg){
    comm_args *args=(comm_args*)arg;
    int counter=1;
    while(1){
        pthread_mutex_lock(&args->lock);
        while(args->mal.attuale!=TO_ELABORATE&&args->mal.islast!=1)pthread_cond_wait(&args->do_mal,&args->lock);
        if(args->mal.islast==1){
            pthread_mutex_unlock(&args->lock);
            break;
        }
        u_int8_t ip[4];
        for(int i=0;i<4;i++)ip[i]=args->mal.controllo.blocco[i];
        u_int16_t porta=args->mal.controllo.blocco[4]|args->mal.controllo.blocco[5];
        u_int8_t pad[2]={args->mal.controllo.blocco[6],args->mal.controllo.blocco[7]};
        printf("[MALFORMATO] controllo record %d dal file %s-> ",counter,args->mal.controllo.filename);
        pthread_mutex_unlock(&args->lock);
        flockfile(stdout);
        printIP(ip,4);
        printf("[MALFORMATO] Numero di porta ->%u e padding %u %u",porta,pad[0],pad[1]);
        funlockfile(stdout);
        if(pad[0]!=0&&pad[1]!=0){
            printf("[MALFORMATO] controllo del record positivo\n");
            pthread_mutex_lock(&args->lock);
            args->mal.controllo.esito=1;
            pthread_mutex_unlock(&args->lock);
        }
        else   printf("[MALFORMATO] controllo del record negativo\n");
        pthread_mutex_lock(&args->lock);
        args->mal.attuale=DONE;
        pthread_cond_broadcast(&args->letto);
        pthread_mutex_unlock(&args->lock);
        counter++;
    }
    printf("[MALFORMATO] terminazione con %d record verificati\n",counter);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]){
    if(argc<2){
        perror("Inserire i file binari\n");
        return EXIT_FAILURE;
    }
    int n=argc-1;
    comm_args args;
    args.broad.attuale=EMPTY;
    args.loopback.attuale=EMPTY;
    args.mal.attuale=EMPTY;
    args.broad.controllo.esito=0;
    args.loopback.controllo.esito=0;
    args.mal.controllo.esito=0;
    args.lett_rim=n;
    pthread_cond_init(&args.do_broad,NULL);
    pthread_cond_init(&args.letto,NULL);
    pthread_cond_init(&args.do_mal,NULL);
    pthread_cond_init(&args.do_loopback,NULL);
    pthread_mutex_init(&args.lock,NULL);
    pthread_t br;
    pthread_t lp;
    pthread_t ml;
    pthread_t *lect=malloc(n*sizeof(pthread_t));
    lect_args* let=malloc(n*sizeof(lect_args));
    printf("[MAIN] Creazione %d thread lettori, %d broadcast,%d loopback e %d malformato\n",n,1,1,1);
    for(int i=0;i<n;i++){
        let[i].args=&args;
        let[i].chek_broad=0;
        let[i].chek_loop=0;
        let[i].chek_mal=0;
        let[i].id=i+1;
        strcpy(let[i].filename,argv[i+1]);
        pthread_create(&lect[i],NULL,lettore,&let[i]);
    }
    pthread_create(&br,NULL,broadcast,&args);
    pthread_create(&lp,NULL,loopback,&args);
    pthread_create(&ml,NULL,malformato,&args);
    for(int i=0;i<n;i++)pthread_join(lect[i],NULL);
    pthread_join(br,NULL);
    pthread_join(lp,NULL);
    pthread_join(ml,NULL);
    pthread_cond_destroy(&args.letto);
    pthread_cond_destroy(&args.do_broad);
    pthread_cond_destroy(&args.do_loopback);
    pthread_cond_destroy(&args.do_mal);
    pthread_mutex_destroy(&args.lock);
    for(int i=0;i<n;i++){
        if(let[i].broad_dic==let[i].chek_broad&&let[i].loop_dic==let[i].chek_loop&&let[i].mal_dic==let[i].chek_mal){
            printf("[MAIN] file %s valido\n",let[i].filename);
        }
        else printf("[MAIN] file %s non valido\n",let[i].filename);
    }
    free(lect);
    free(let);
    return EXIT_SUCCESS;
}
