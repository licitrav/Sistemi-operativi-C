#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/stat.h>
#include <sys/mman.h>

#define CAP_CAN 10
#define CAP_S 5
#define MIN 480
#define MAX 520



typedef struct{
    u_int8_t grezzo[8];
    u_int32_t codice;
    u_int32_t peso;
    int id;
    int isLast;
}prodotto;

typedef struct Node{
    prodotto val;
    struct Node* next;
}Node;

typedef struct{
    Node* head;
    Node* rear;
    sem_t full;
    sem_t empty;
    pthread_mutex_t lockt;
}tail;

typedef struct{
    int dichiarati;
    int validi;
}checker;

typedef struct{
    tail *candidati;
    tail *scarti;
    int m;
    int lett_rim;
    checker* stat;
    pthread_mutex_t lock;
}comm_args;

typedef struct{
    comm_args *args;
    int id;
    char filename[255];
}lect_args;

typedef struct{
    int id;
    comm_args *args;
}ver_args;

void push(tail* coda,prodotto t){
    sem_wait(&coda->full);
    Node *new=malloc(sizeof(Node));
    new->next=NULL;
    new->val=t;
    pthread_mutex_lock(&coda->lockt);
    if(coda->head==NULL){
        coda->head=new;
        coda->rear=new;
    }
    else{
        coda->rear->next=new;
        coda->rear=new;
    }
    sem_post(&coda->empty);
    pthread_mutex_unlock(&coda->lockt);
}

void pop(tail *coda,prodotto *t){
    sem_wait(&coda->empty);
    pthread_mutex_lock(&coda->lockt);
    if(coda->head==NULL){
        pthread_mutex_unlock(&coda->lockt);
        return;
    }
    Node *old=coda->head;
    *t=old->val;
    coda->head=coda->head->next;
    free(old);
    sem_post(&coda->full);
    pthread_mutex_unlock(&coda->lockt);
}

u_int32_t sumEND(u_int32_t a,u_int32_t b,u_int32_t c,u_int32_t d){return a|b<<8|c<<16|d<<24; }
void printVEC(u_int8_t vec[8]){
    for(int i=0;i<8;i++)printf("%u ",vec[i]);
    printf("\n");
}
void *lettore(void *arg){
    lect_args *args=(lect_args*)arg;
    int fd;
    struct stat sb;
    off_t h;
    u_int8_t *p;
    fd=open(args->filename,O_RDONLY);
    if(fd==-1){
        perror("Errore apertura file\n");
        pthread_mutex_lock(&args->args->lock);
        args->args->lett_rim--;
        if(args->args->lett_rim==0){
            prodotto pill;
            pill.isLast=1;
            int m=args->args->m;
            pthread_mutex_unlock(&args->args->lock);
            for(int i=0;i<m;i++){
                push(args->args->candidati,pill);
            }
        }
        else pthread_mutex_unlock(&args->args->lock);
    }
    if(fstat(fd,&sb)==-1){
        perror("Errore in fstat\n");
        pthread_mutex_lock(&args->args->lock);
        args->args->lett_rim--;
        if(args->args->lett_rim==0){
            prodotto pill;
            pill.isLast=1;
            int m=args->args->m;
            pthread_mutex_unlock(&args->args->lock);
            for(int i=0;i<m;i++){
                push(args->args->candidati,pill);
            }
        }
        else pthread_mutex_unlock(&args->args->lock);
    }
    p=mmap(NULL,sb.st_size,PROT_READ,MAP_PRIVATE,fd,0);
    if(p==MAP_FAILED){
        perror("Errore mmap\n");
        pthread_mutex_lock(&args->args->lock);
        args->args->lett_rim--;
        if(args->args->lett_rim==0){
            prodotto pill;
            pill.isLast=1;
            int m=args->args->m;
            pthread_mutex_unlock(&args->args->lock);
            for(int i=0;i<m;i++){
                push(args->args->candidati,pill);
            }
        }
        else pthread_mutex_unlock(&args->args->lock);
    }
    if(close(fd)==-1){
        perror("Errore chiusura file\n");
        pthread_mutex_lock(&args->args->lock);
        args->args->lett_rim--;
        if(args->args->lett_rim==0){
            prodotto pill;
            pill.isLast=1;
            int m=args->args->m;
            pthread_mutex_unlock(&args->args->lock);
            for(int i=0;i<m;i++){
                push(args->args->candidati,pill);
            }
        }
        else pthread_mutex_unlock(&args->args->lock);
    }
    u_int8_t header[4];
    for(h=0;h<4;h++)header[h]=p[h];
    pthread_mutex_lock(&args->args->lock);
    args->args->stat[args->id-1].dichiarati=sumEND((u_int32_t)header[0],(u_int32_t)header[1],(u_int32_t)header[2],(u_int32_t)header[3]);
    printf("[READER-%d] Leggo il file %s con %u dichiarati\n",args->id,args->filename,args->args->stat[args->id-1].dichiarati);
    pthread_mutex_unlock(&args->args->lock);
    int tot=(sb.st_size-4)/8;
    int counter=1;
    for(int i=0;i<tot;i++){
        off_t offset=4+(off_t)i*8;
        prodotto t;
        t.id=args->id-1;
        t.isLast=0;
        for(int j=0;j<8;j++)t.grezzo[j]=p[j+offset];
        flockfile(stdout);
        printf("[READER-%d] ricevuto il prodotto n.%d ",args->id,counter);
        printVEC(t.grezzo);
        funlockfile(stdout);
        push(args->args->candidati,t);
        counter++;
    }
    if(munmap(p,sb.st_size)==-1){
        perror("Errore in munmap");
    }
    pthread_mutex_lock(&args->args->lock);
    args->args->lett_rim--;
    if(args->args->lett_rim==0){
        prodotto pill;
        pill.isLast=1;
        int m=args->args->m;
        pthread_mutex_unlock(&args->args->lock);
        for(int i=0;i<m;i++){
                push(args->args->candidati,pill);
        }
    }
    else pthread_mutex_unlock(&args->args->lock);
    printf("[READER-%d] termino con %d prodotti letti\n",args->id,counter);
    pthread_exit(NULL);
}

void *controllore(void *arg){
    ver_args *args=(ver_args*)arg;
    int counter=1;
    while(1){
        prodotto t;
        pop(args->args->candidati,&t);
        if(t.isLast==1){
            push(args->args->scarti,t);
            break;
        }
        printf("[VER-%d] ricevo dal READER-%d il prodotto %d\n",args->id,t.id+1,counter);
        t.codice=sumEND((u_int32_t)t.grezzo[0],(u_int32_t)t.grezzo[1],(u_int32_t)t.grezzo[2],(u_int32_t)t.grezzo[3]);
        t.peso=sumEND((u_int32_t)t.grezzo[4],(u_int32_t)t.grezzo[5],(u_int32_t)t.grezzo[6],(u_int32_t)t.grezzo[7]);
        if(t.peso>=MIN&&t.peso<=MAX){
            printf("[VER-%d] Il prodotto proveniente da READER-%d con codice %u e peso %u è valido\n",args->id,t.id+1,t.codice,t.peso);
            pthread_mutex_lock(&args->args->lock);
            args->args->stat[t.id].validi++;
            pthread_mutex_unlock(&args->args->lock);
        }
        else{
            printf("[VER-%d] Il prodotto proveniente da READER-%d con codice %u e peso %u non è valido\n",args->id,t.id+1,t.codice,t.peso);
            push(args->args->scarti,t);
        }
        counter++;
    }
    printf("[VER-%d] termino con %d prodotti verificati\n",args->id,counter);
    pthread_exit(NULL);
}
void tailInit(tail *coda,int n){
    coda->head=NULL;
    coda->rear=NULL;
    pthread_mutex_init(&coda->lockt,NULL);
    sem_init(&coda->full,0,n);
    sem_init(&coda->empty,0,0);
}
void tailDestroy(tail *coda){
    pthread_mutex_destroy(&coda->lockt);
    sem_destroy(&coda->full);
    sem_destroy(&coda->empty);
}
int main(int argc, char* argv[]){
    if(argc<3){
        perror("Inserire numero controllori e file binari \n");
        return EXIT_FAILURE;
    }
    int n=argc-2;
    int m=atoi(argv[1]);
    tail candidati;
    tail scarti;
    checker *statistica=calloc(n,sizeof(checker));
    tailInit(&candidati,CAP_CAN);
    tailInit(&scarti,CAP_S);
    comm_args args;
    args.m=m;
    args.lett_rim=n;
    args.candidati=&candidati;
    args.scarti=&scarti;
    args.stat=statistica;
    pthread_mutex_init(&args.lock,NULL);
    pthread_t *lect=malloc(n*sizeof(pthread_t));
    pthread_t *veri=malloc(m*sizeof(pthread_t));
    lect_args *let=malloc(n*sizeof(lect_args));
    ver_args *ver=malloc(m*sizeof(ver_args));
    printf("[MAIN] creazione %d thread lettori e %d thread controllori\n",n,m);
    for(int i=0;i<n;i++){
        let[i].id=i+1;
        strcpy(let[i].filename,argv[i+2]);
        printf("[MAIN] %s\n",let[i].filename);
        let[i].args=&args;
        pthread_create(&lect[i],NULL,lettore,&let[i]);
    }
    for(int i=0;i<m;i++){
        ver[i].id=i+1;
        ver[i].args=&args;
        pthread_create(&veri[i],NULL,controllore,&ver[i]);
    }
    int ver_rim=m;
    while(ver_rim>0){
        prodotto t;
        pop(&scarti,&t);
        if(t.isLast==1){
            ver_rim--;
            continue;
        }
        printf("[MAIN] il prodotto proveniente dal REDAER-%d con codice %u è stato scartato con peso pari a %u\n",t.id+1,t.codice,t.peso);
    }
    for(int i=0;i<n;i++)pthread_join(lect[i],NULL);
    for(int i=0;i<m;i++)pthread_join(veri[i],NULL);
    pthread_mutex_destroy(&args.lock);
    tailDestroy(&candidati);
    tailDestroy(&scarti);
    for(int i=0;i<n;i++){
        if(statistica[i].dichiarati==statistica[i].validi)printf("[MAIN] il file %s è valido\n",let[i].filename);
        else printf("[MAIN] il file %s non è valido\n",let[i].filename);
    }
    free(lect);
    free(veri);
    free(let);
    free(ver);
    free(statistica);
    printf("[MAIN] terminazione\n");
}
